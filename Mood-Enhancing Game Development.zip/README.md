
  # Mood-Enhancing Game Development

  This is a code bundle for Mood-Enhancing Game Development. The original project is available at https://www.figma.com/design/PwWf2Tr0lsbj1UnM74z6FY/Mood-Enhancing-Game-Development.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  