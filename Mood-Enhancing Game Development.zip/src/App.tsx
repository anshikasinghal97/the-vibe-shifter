import { useState, useEffect } from 'react';
import { LoginPage } from './components/LoginPage';
import { GameIntro } from './components/GameIntro';
import { QuestionScreen } from './components/QuestionScreen';
import { MiniGamesScreen } from './components/MiniGamesScreen';
import { ActivityScreen } from './components/ActivityScreen';
import { questions } from './data/questions';
import { User, GameState, MoodType } from './types/game';
import { Toaster } from './components/ui/sonner';
import { toast } from 'sonner@2.0.3';

type AppState = 'login' | 'intro' | 'playing' | 'minigames' | 'activities';

function App() {
  const [appState, setAppState] = useState<AppState>('login');
  const [user, setUser] = useState<User | null>(null);
  const [gameState, setGameState] = useState<GameState>({
    currentQuestionIndex: 0,
    answers: [],
    moodScores: {
      stressed: 0,
      anxious: 0,
      sad: 0,
      neutral: 0,
      happy: 0,
      excited: 0,
    },
    startTime: Date.now(),
    currentMood: 'neutral',
    phase: 'detection',
  });

  // Calculate current mood based on scores
  useEffect(() => {
    const scores = gameState.moodScores;
    const maxScore = Math.max(...Object.values(scores));
    const dominantMood = (Object.keys(scores) as MoodType[]).find(
      (key) => scores[key] === maxScore
    ) || 'neutral';
    
    if (dominantMood !== gameState.currentMood) {
      setGameState((prev) => ({ ...prev, currentMood: dominantMood }));
    }
  }, [gameState.moodScores]);

  const handleLogin = (userData: User) => {
    setUser(userData);
    setAppState('intro');
    toast.success(`Welcome, ${userData.name}! 🎉`);
  };

  const handleStartGame = () => {
    setGameState({
      currentQuestionIndex: 0,
      answers: [],
      moodScores: {
        stressed: 0,
        anxious: 0,
        sad: 0,
        neutral: 0,
        happy: 0,
        excited: 0,
      },
      startTime: Date.now(),
      currentMood: 'neutral',
      phase: 'detection',
    });
    setAppState('playing');
  };

  const handleAnswer = (optionIndex: number) => {
    const currentQuestion = questions[gameState.currentQuestionIndex];
    const selectedOption = currentQuestion.options[optionIndex];

    // Update mood scores
    const newMoodScores = { ...gameState.moodScores };
    Object.entries(selectedOption.moodImpact).forEach(([mood, impact]) => {
      if (impact) {
        newMoodScores[mood as MoodType] += impact;
      }
    });

    // Update game state
    const newAnswers = [...gameState.answers, optionIndex];
    const nextIndex = gameState.currentQuestionIndex + 1;

    setGameState((prev) => ({
      ...prev,
      answers: newAnswers,
      moodScores: newMoodScores,
      currentQuestionIndex: nextIndex,
    }));

    // Check if game is complete
    if (nextIndex >= questions.length) {
      // Add a small delay before showing mini games
      setTimeout(() => {
        setAppState('minigames');
        toast.success('Questions complete! Time for some fun mini-games! 🎮');
      }, 1000);
    } else {
      // Provide encouraging feedback
      if (nextIndex === 10) {
        toast.success('Great job! Now let\'s have some fun! 🎉');
      } else if (nextIndex === 20) {
        toast.success('You\'re doing amazing! Almost there! ⭐');
      }
    }
  };

  const handleMiniGamesComplete = () => {
    setAppState('activities');
    toast.success('Great work! Here are your personalized activities 🌟');
  };

  const handleRestart = () => {
    setAppState('intro');
    toast.info('Ready for another session? Let\'s go! 🚀');
  };

  if (appState === 'login') {
    return (
      <>
        <LoginPage onLogin={handleLogin} />
        <Toaster position="top-center" />
      </>
    );
  }

  if (appState === 'intro' && user) {
    return (
      <>
        <GameIntro user={user} onStart={handleStartGame} />
        <Toaster position="top-center" />
      </>
    );
  }

  if (appState === 'playing') {
    const currentQuestion = questions[gameState.currentQuestionIndex];
    
    // Safety check: if no question found, move to minigames
    if (!currentQuestion) {
      setAppState('minigames');
      return null;
    }
    
    return (
      <>
        <QuestionScreen
          question={currentQuestion}
          currentIndex={gameState.currentQuestionIndex}
          totalQuestions={questions.length}
          currentMood={gameState.currentMood}
          onAnswer={handleAnswer}
        />
        <Toaster position="top-center" />
      </>
    );
  }

  if (appState === 'minigames') {
    return (
      <>
        <MiniGamesScreen
          mood={gameState.currentMood}
          onComplete={handleMiniGamesComplete}
        />
        <Toaster position="top-center" />
      </>
    );
  }

  if (appState === 'activities' && user) {
    return (
      <>
        <ActivityScreen
          mood={gameState.currentMood}
          userName={user.name}
          onRestart={handleRestart}
        />
        <Toaster position="top-center" />
      </>
    );
  }

  return null;
}

export default App;
