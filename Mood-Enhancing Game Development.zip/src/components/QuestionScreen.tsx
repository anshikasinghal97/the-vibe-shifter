import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Progress } from './ui/progress';
import { AnimatedCharacter } from './AnimatedCharacter';
import { Question, MoodType } from '../types/game';

interface QuestionScreenProps {
  question: Question;
  currentIndex: number;
  totalQuestions: number;
  currentMood: MoodType;
  onAnswer: (optionIndex: number) => void;
}

export function QuestionScreen({
  question,
  currentIndex,
  totalQuestions,
  currentMood,
  onAnswer,
}: QuestionScreenProps) {
  // Safety check
  if (!question) {
    return null;
  }

  const progress = ((currentIndex + 1) / totalQuestions) * 100;

  const getCategoryColor = () => {
    switch (question.category) {
      case 'mood-detection':
        return 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300';
      case 'fun':
        return 'bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-300';
      case 'stress-relief':
        return 'bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300';
      default:
        return 'bg-gray-100 dark:bg-gray-900 text-gray-700 dark:text-gray-300';
    }
  };

  const getCategoryLabel = () => {
    switch (question.category) {
      case 'mood-detection':
        return 'Mood Check';
      case 'fun':
        return 'Fun Time!';
      case 'stress-relief':
        return 'Feel Good';
      default:
        return 'Question';
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-violet-500 via-purple-500 to-fuchsia-500 p-4">
      <Card className="max-w-3xl w-full">
        <CardHeader>
          <div className="flex items-center justify-between mb-4">
            <span className={`px-3 py-1 rounded-full text-sm ${getCategoryColor()}`}>
              {getCategoryLabel()}
            </span>
            <span className="text-sm text-muted-foreground">
              Question {currentIndex + 1} of {totalQuestions}
            </span>
          </div>
          <Progress value={progress} className="mb-4" />
          <CardTitle className="text-2xl">{question.text}</CardTitle>
          <CardDescription>Choose the option that resonates with you most</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <AnimatedCharacter mood={currentMood} />
          
          <div className="grid gap-3">
            {question.options.map((option, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Button
                  variant="outline"
                  className="w-full h-auto py-4 px-6 text-left justify-start hover:bg-purple-100 dark:hover:bg-purple-900 hover:border-purple-400 transition-all"
                  onClick={() => onAnswer(index)}
                >
                  <span className="mr-3 text-lg">{String.fromCharCode(65 + index)}.</span>
                  <span>{option.text}</span>
                </Button>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
