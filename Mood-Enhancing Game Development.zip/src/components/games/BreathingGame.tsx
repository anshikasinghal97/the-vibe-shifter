import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Button } from '../ui/button';

export function BreathingGame({ onComplete }: { onComplete: () => void }) {
  const [phase, setPhase] = useState<'inhale' | 'hold' | 'exhale' | 'complete'>('inhale');
  const [count, setCount] = useState(4);
  const [cycles, setCycles] = useState(0);
  const [started, setStarted] = useState(false);

  useEffect(() => {
    if (!started) return;

    if (count > 0) {
      const timer = setTimeout(() => setCount(count - 1), 1000);
      return () => clearTimeout(timer);
    } else {
      // Move to next phase
      if (phase === 'inhale') {
        setPhase('hold');
        setCount(4);
      } else if (phase === 'hold') {
        setPhase('exhale');
        setCount(4);
      } else if (phase === 'exhale') {
        const newCycles = cycles + 1;
        setCycles(newCycles);
        if (newCycles >= 4) {
          setPhase('complete');
          setTimeout(() => onComplete(), 2000);
        } else {
          setPhase('inhale');
          setCount(4);
        }
      }
    }
  }, [count, phase, cycles, started, onComplete]);

  const getInstruction = () => {
    switch (phase) {
      case 'inhale':
        return 'Breathe In...';
      case 'hold':
        return 'Hold...';
      case 'exhale':
        return 'Breathe Out...';
      case 'complete':
        return 'Amazing! You did it! 🌟';
    }
  };

  const getScale = () => {
    if (phase === 'inhale') return 1.5;
    if (phase === 'hold') return 1.5;
    return 0.5;
  };

  if (!started) {
    return (
      <div className="text-center space-y-6">
        <h3 className="text-2xl">Calming Breath Exercise 🫁</h3>
        <p>Follow the circle and breathe with the rhythm</p>
        <p className="text-sm text-muted-foreground">4 cycles of breathing to center yourself</p>
        <Button onClick={() => setStarted(true)} size="lg">Begin</Button>
      </div>
    );
  }

  if (phase === 'complete') {
    return (
      <div className="text-center space-y-4">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="text-6xl"
        >
          ✨
        </motion.div>
        <h3 className="text-2xl">Perfect! You're now more relaxed 😌</h3>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center space-y-8">
      <p className="text-3xl">{getInstruction()}</p>
      <p className="text-6xl">{count}</p>
      
      <motion.div
        animate={{ scale: getScale() }}
        transition={{ duration: 4, ease: 'easeInOut' }}
        className="w-48 h-48 rounded-full bg-gradient-to-br from-blue-400 to-purple-500 shadow-2xl"
      />
      
      <p className="text-sm text-muted-foreground">
        Cycle {cycles + 1} of 4
      </p>
    </div>
  );
}
