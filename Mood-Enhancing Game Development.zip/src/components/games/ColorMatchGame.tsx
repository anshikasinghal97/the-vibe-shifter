import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Button } from '../ui/button';

const colors = [
  { name: 'Red', bg: 'bg-red-500', text: 'Red' },
  { name: 'Blue', bg: 'bg-blue-500', text: 'Blue' },
  { name: 'Green', bg: 'bg-green-500', text: 'Green' },
  { name: 'Yellow', bg: 'bg-yellow-500', text: 'Yellow' },
  { name: 'Purple', bg: 'bg-purple-500', text: 'Purple' },
  { name: 'Pink', bg: 'bg-pink-500', text: 'Pink' },
];

export function ColorMatchGame({ onComplete }: { onComplete: () => void }) {
  const [currentColor, setCurrentColor] = useState(colors[0]);
  const [displayedText, setDisplayedText] = useState(colors[1]);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [gameStarted, setGameStarted] = useState(false);

  useEffect(() => {
    if (gameStarted && timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0) {
      setTimeout(() => onComplete(), 1500);
    }
  }, [timeLeft, gameStarted, onComplete]);

  const generateNewRound = () => {
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    const randomText = colors[Math.floor(Math.random() * colors.length)];
    setCurrentColor(randomColor);
    setDisplayedText(randomText);
  };

  const handleAnswer = (match: boolean) => {
    const isCorrect = (currentColor.name === displayedText.name) === match;
    if (isCorrect) {
      setScore(score + 1);
    }
    generateNewRound();
  };

  const startGame = () => {
    setGameStarted(true);
    generateNewRound();
  };

  if (!gameStarted) {
    return (
      <div className="text-center space-y-4">
        <h3 className="text-2xl">Color Match Challenge! 🎨</h3>
        <p>Press "MATCH" if the color and word match, "NO MATCH" if they don't!</p>
        <p className="text-sm text-muted-foreground">You have 30 seconds. How many can you get?</p>
        <Button onClick={startGame} size="lg">Start Game!</Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <p>Score: {score}</p>
        <p>Time: {timeLeft}s</p>
      </div>
      
      <motion.div
        key={currentColor.name + displayedText.name}
        initial={{ scale: 0, rotate: -180 }}
        animate={{ scale: 1, rotate: 0 }}
        className={`${currentColor.bg} p-12 rounded-2xl text-center`}
      >
        <p className="text-5xl text-white drop-shadow-lg">
          {displayedText.text}
        </p>
      </motion.div>

      <div className="grid grid-cols-2 gap-4">
        <Button
          onClick={() => handleAnswer(true)}
          size="lg"
          className="bg-green-500 hover:bg-green-600 h-20"
        >
          ✓ MATCH
        </Button>
        <Button
          onClick={() => handleAnswer(false)}
          size="lg"
          className="bg-red-500 hover:bg-red-600 h-20"
        >
          ✗ NO MATCH
        </Button>
      </div>

      {timeLeft === 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center text-2xl"
        >
          Great job! Final Score: {score} 🎉
        </motion.div>
      )}
    </div>
  );
}
