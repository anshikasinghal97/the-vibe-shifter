import { motion } from 'motion/react';
import { Sparkles, Star, Heart, Zap } from 'lucide-react';
import { useEffect, useState } from 'react';

interface AnimatedCharacterProps {
  mood: 'stressed' | 'anxious' | 'sad' | 'neutral' | 'happy' | 'excited';
}

export function AnimatedCharacter({ mood }: AnimatedCharacterProps) {
  const [particles, setParticles] = useState<number[]>([]);

  useEffect(() => {
    const interval = setInterval(() => {
      setParticles([...Array(5)].map((_, i) => i + Math.random()));
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const getMoodColor = () => {
    switch (mood) {
      case 'stressed':
      case 'anxious':
        return 'from-red-400 to-orange-400';
      case 'sad':
        return 'from-blue-400 to-indigo-400';
      case 'neutral':
        return 'from-gray-400 to-slate-400';
      case 'happy':
        return 'from-green-400 to-emerald-400';
      case 'excited':
        return 'from-purple-400 to-pink-400';
    }
  };

  return (
    <div className="relative flex justify-center items-center h-64">
      {/* Magical particles */}
      {particles.map((particle, i) => (
        <motion.div
          key={particle}
          initial={{ opacity: 0, scale: 0, x: 0, y: 0 }}
          animate={{
            opacity: [0, 1, 0],
            scale: [0, 1.5, 0],
            x: [0, (Math.random() - 0.5) * 200],
            y: [0, (Math.random() - 0.5) * 200],
          }}
          transition={{ duration: 2, ease: 'easeOut' }}
          className="absolute"
        >
          {i % 4 === 0 && <Sparkles className="w-4 h-4 text-yellow-400" />}
          {i % 4 === 1 && <Star className="w-4 h-4 text-pink-400" />}
          {i % 4 === 2 && <Heart className="w-4 h-4 text-red-400" />}
          {i % 4 === 3 && <Zap className="w-4 h-4 text-blue-400" />}
        </motion.div>
      ))}

      {/* Main character body */}
      <motion.div
        animate={{
          y: [0, -20, 0],
        }}
        transition={{
          duration: 3,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        className="relative"
      >
        {/* Glow effect */}
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.6, 0.3],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
          className={`absolute inset-0 rounded-full bg-gradient-to-r ${getMoodColor()} blur-xl`}
        />

        {/* Character body */}
        <div className={`relative w-32 h-32 rounded-full bg-gradient-to-br ${getMoodColor()} flex items-center justify-center shadow-2xl`}>
          {/* Face */}
          <div className="relative">
            {/* Eyes */}
            <motion.div
              animate={{
                scaleY: [1, 0.1, 1],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                repeatDelay: 2,
              }}
              className="flex gap-4 mb-4"
            >
              <div className="w-3 h-3 bg-white rounded-full" />
              <div className="w-3 h-3 bg-white rounded-full" />
            </motion.div>

            {/* Mouth based on mood */}
            <motion.div
              animate={{
                scale: [1, 1.1, 1],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
              }}
            >
              {(mood === 'happy' || mood === 'excited') && (
                <div className="w-8 h-4 border-b-4 border-white rounded-b-full" />
              )}
              {mood === 'neutral' && (
                <div className="w-8 h-1 bg-white rounded-full" />
              )}
              {(mood === 'sad' || mood === 'stressed' || mood === 'anxious') && (
                <div className="w-8 h-4 border-t-4 border-white rounded-t-full" />
              )}
            </motion.div>
          </div>

          {/* Magic wand */}
          <motion.div
            animate={{
              rotate: [0, -30, 30, 0],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
            className="absolute -right-8 top-8"
          >
            <Sparkles className="w-8 h-8 text-yellow-300" />
          </motion.div>
        </div>

        {/* Magical sparkles around character */}
        <motion.div
          animate={{
            rotate: 360,
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: 'linear',
          }}
          className="absolute inset-0"
        >
          {[...Array(8)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute"
              style={{
                top: '50%',
                left: '50%',
                transform: `rotate(${i * 45}deg) translateX(80px)`,
              }}
              animate={{
                scale: [1, 1.5, 1],
                opacity: [0.3, 1, 0.3],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                delay: i * 0.2,
              }}
            >
              <Star className="w-3 h-3 text-yellow-300" />
            </motion.div>
          ))}
        </motion.div>
      </motion.div>
    </div>
  );
}
