import { Question } from '../types/game';

export const questions: Question[] = [
  // Mood Detection Questions (1-10)
  {
    id: 1,
    text: "How would you describe your energy level right now?",
    category: 'mood-detection',
    options: [
      { text: "Completely drained", moodImpact: { stressed: 3, sad: 2 } },
      { text: "Low energy", moodImpact: { stressed: 2, neutral: 1 } },
      { text: "Moderate", moodImpact: { neutral: 3 } },
      { text: "Energetic", moodImpact: { happy: 2, excited: 1 } },
      { text: "Super charged!", moodImpact: { excited: 3, happy: 2 } }
    ]
  },
  {
    id: 2,
    text: "How many hours did you sleep last night?",
    category: 'mood-detection',
    options: [
      { text: "Less than 4 hours", moodImpact: { stressed: 3, anxious: 2 } },
      { text: "4-6 hours", moodImpact: { stressed: 2, neutral: 1 } },
      { text: "6-8 hours", moodImpact: { neutral: 2, happy: 1 } },
      { text: "More than 8 hours", moodImpact: { happy: 2, neutral: 1 } }
    ]
  },
  {
    id: 3,
    text: "When thinking about tomorrow, you feel...",
    category: 'mood-detection',
    options: [
      { text: "Overwhelmed and worried", moodImpact: { anxious: 3, stressed: 2 } },
      { text: "A bit uncertain", moodImpact: { anxious: 2, neutral: 1 } },
      { text: "Pretty neutral about it", moodImpact: { neutral: 3 } },
      { text: "Hopeful and ready", moodImpact: { happy: 2, excited: 1 } },
      { text: "Excited for new opportunities!", moodImpact: { excited: 3, happy: 2 } }
    ]
  },
  {
    id: 4,
    text: "How often have you felt like giving up this week?",
    category: 'mood-detection',
    options: [
      { text: "Many times", moodImpact: { stressed: 3, sad: 3 } },
      { text: "A few times", moodImpact: { stressed: 2, anxious: 2 } },
      { text: "Once or twice", moodImpact: { neutral: 2, stressed: 1 } },
      { text: "Not at all", moodImpact: { happy: 3, excited: 1 } }
    ]
  },
  {
    id: 5,
    text: "What's your breathing like right now?",
    category: 'mood-detection',
    options: [
      { text: "Shallow and rapid", moodImpact: { anxious: 3, stressed: 2 } },
      { text: "A bit irregular", moodImpact: { anxious: 2, stressed: 1 } },
      { text: "Normal and steady", moodImpact: { neutral: 3 } },
      { text: "Deep and relaxed", moodImpact: { happy: 3, neutral: 1 } }
    ]
  },
  {
    id: 6,
    text: "How's your appetite been lately?",
    category: 'mood-detection',
    options: [
      { text: "No appetite at all", moodImpact: { sad: 3, stressed: 2 } },
      { text: "Less than usual", moodImpact: { stressed: 2, anxious: 1 } },
      { text: "Normal", moodImpact: { neutral: 3 } },
      { text: "Great appetite!", moodImpact: { happy: 2, excited: 1 } }
    ]
  },
  {
    id: 7,
    text: "When you look in the mirror, what do you see?",
    category: 'mood-detection',
    options: [
      { text: "Someone tired and worn out", moodImpact: { sad: 3, stressed: 2 } },
      { text: "Someone struggling", moodImpact: { stressed: 2, sad: 1 } },
      { text: "Just me, nothing special", moodImpact: { neutral: 3 } },
      { text: "Someone doing their best", moodImpact: { happy: 2, neutral: 1 } },
      { text: "A champion!", moodImpact: { excited: 3, happy: 2 } }
    ]
  },
  {
    id: 8,
    text: "How would you rate your stress level right now (1-10)?",
    category: 'mood-detection',
    options: [
      { text: "9-10 (Extremely high)", moodImpact: { stressed: 4, anxious: 3 } },
      { text: "7-8 (High)", moodImpact: { stressed: 3, anxious: 2 } },
      { text: "4-6 (Moderate)", moodImpact: { stressed: 2, neutral: 2 } },
      { text: "1-3 (Low)", moodImpact: { happy: 2, neutral: 2 } },
      { text: "0 (No stress!)", moodImpact: { happy: 3, excited: 2 } }
    ]
  },
  {
    id: 9,
    text: "How easy is it for you to focus right now?",
    category: 'mood-detection',
    options: [
      { text: "Nearly impossible", moodImpact: { stressed: 3, anxious: 2 } },
      { text: "Very difficult", moodImpact: { stressed: 2, anxious: 2 } },
      { text: "Somewhat challenging", moodImpact: { neutral: 2, stressed: 1 } },
      { text: "Pretty easy", moodImpact: { happy: 2, neutral: 1 } },
      { text: "Laser focused!", moodImpact: { excited: 2, happy: 2 } }
    ]
  },
  {
    id: 10,
    text: "If you could describe your day in one word, it would be...",
    category: 'mood-detection',
    options: [
      { text: "Overwhelming", moodImpact: { stressed: 3, anxious: 2 } },
      { text: "Challenging", moodImpact: { stressed: 2, neutral: 1 } },
      { text: "Okay", moodImpact: { neutral: 3 } },
      { text: "Good", moodImpact: { happy: 2, neutral: 1 } },
      { text: "Amazing!", moodImpact: { excited: 3, happy: 2 } }
    ]
  },
  
  // Fun & Mood Improvement Questions (11-20)
  {
    id: 11,
    text: "If you could have any superpower right now, what would it be?",
    category: 'fun',
    options: [
      { text: "Time manipulation - pause and relax", moodImpact: { happy: 2, neutral: 1 } },
      { text: "Teleportation - escape anywhere!", moodImpact: { excited: 2, happy: 1 } },
      { text: "Mind reading - understand everyone", moodImpact: { happy: 2, excited: 1 } },
      { text: "Super strength - overcome anything!", moodImpact: { excited: 3, happy: 1 } }
    ]
  },
  {
    id: 12,
    text: "You find a magic lamp! What's your first wish?",
    category: 'fun',
    options: [
      { text: "Infinite peace of mind", moodImpact: { happy: 3, neutral: 1 } },
      { text: "Adventure around the world", moodImpact: { excited: 3, happy: 2 } },
      { text: "Perfect health for everyone", moodImpact: { happy: 2, excited: 1 } },
      { text: "Unlimited pizza!", moodImpact: { excited: 2, happy: 2 } }
    ]
  },
  {
    id: 13,
    text: "What's your ideal way to spend a Sunday?",
    category: 'fun',
    options: [
      { text: "Cozy blanket, good book, hot chocolate", moodImpact: { happy: 3, neutral: 1 } },
      { text: "Adventure sports and outdoor fun", moodImpact: { excited: 3, happy: 2 } },
      { text: "Gaming marathon with friends", moodImpact: { excited: 2, happy: 2 } },
      { text: "Cooking something delicious", moodImpact: { happy: 2, excited: 1 } }
    ]
  },
  {
    id: 14,
    text: "If animals could talk, which would be the funniest?",
    category: 'fun',
    options: [
      { text: "Cats - sarcastic commentary all day", moodImpact: { happy: 3, excited: 1 } },
      { text: "Dogs - endless enthusiasm!", moodImpact: { excited: 3, happy: 2 } },
      { text: "Penguins - awkward waddle talks", moodImpact: { happy: 3, excited: 2 } },
      { text: "Dolphins - underwater comedy shows", moodImpact: { excited: 2, happy: 2 } }
    ]
  },
  {
    id: 15,
    text: "You're a video game character! What's your special move?",
    category: 'fun',
    options: [
      { text: "Mega relaxation beam", moodImpact: { happy: 2, neutral: 1 } },
      { text: "Triple jump excitement!", moodImpact: { excited: 3, happy: 1 } },
      { text: "Friendship power-up", moodImpact: { happy: 3, excited: 1 } },
      { text: "Dance attack!", moodImpact: { excited: 3, happy: 2 } }
    ]
  },
  {
    id: 16,
    text: "What would be the best ice cream flavor combo?",
    category: 'fun',
    options: [
      { text: "Chocolate + Vanilla (Classic!)", moodImpact: { happy: 2, neutral: 1 } },
      { text: "Mango + Chili (Adventurous!)", moodImpact: { excited: 3, happy: 1 } },
      { text: "Cookies + Caramel (Sweet chaos!)", moodImpact: { excited: 2, happy: 2 } },
      { text: "Mint + Chocolate chip (Refreshing!)", moodImpact: { happy: 3, excited: 1 } }
    ]
  },
  {
    id: 17,
    text: "If you could live in any fictional world, where would it be?",
    category: 'fun',
    options: [
      { text: "Harry Potter - Magic everywhere!", moodImpact: { excited: 3, happy: 2 } },
      { text: "Pokemon - Catch 'em all!", moodImpact: { excited: 3, happy: 2 } },
      { text: "Animal Crossing - Peaceful island life", moodImpact: { happy: 3, neutral: 1 } },
      { text: "Star Wars - Epic space adventures!", moodImpact: { excited: 4, happy: 2 } }
    ]
  },
  {
    id: 18,
    text: "What's your go-to dance move?",
    category: 'fun',
    options: [
      { text: "The robot - beep boop!", moodImpact: { excited: 2, happy: 2 } },
      { text: "Moonwalk - smooth criminal!", moodImpact: { excited: 3, happy: 2 } },
      { text: "Floss - gaming legend!", moodImpact: { excited: 3, happy: 2 } },
      { text: "Just vibing - free style!", moodImpact: { happy: 3, excited: 2 } }
    ]
  },
  {
    id: 19,
    text: "You can instantly master any skill! Which one?",
    category: 'fun',
    options: [
      { text: "Playing any musical instrument", moodImpact: { happy: 2, excited: 2 } },
      { text: "Speaking all languages", moodImpact: { excited: 2, happy: 2 } },
      { text: "Cooking like a master chef", moodImpact: { happy: 3, excited: 1 } },
      { text: "Parkour and acrobatics!", moodImpact: { excited: 4, happy: 2 } }
    ]
  },
  {
    id: 20,
    text: "What's the most ridiculous thing you'd do if you won the lottery?",
    category: 'fun',
    options: [
      { text: "Build a pillow fort mansion", moodImpact: { excited: 3, happy: 3 } },
      { text: "Buy an island for my pets", moodImpact: { excited: 3, happy: 2 } },
      { text: "Create the world's biggest pizza", moodImpact: { excited: 4, happy: 3 } },
      { text: "Fund a real-life Mario Kart league", moodImpact: { excited: 4, happy: 3 } }
    ]
  },

  // Stress Relief & Reflection Questions (21-30)
  {
    id: 21,
    text: "What makes you smile without fail?",
    category: 'stress-relief',
    options: [
      { text: "Cute animal videos", moodImpact: { happy: 3, excited: 1 } },
      { text: "Spending time with loved ones", moodImpact: { happy: 4, excited: 1 } },
      { text: "Accomplishing a goal", moodImpact: { happy: 3, excited: 2 } },
      { text: "Random acts of kindness", moodImpact: { happy: 4, excited: 2 } }
    ]
  },
  {
    id: 22,
    text: "When you need to relax, you...",
    category: 'stress-relief',
    options: [
      { text: "Listen to calming music", moodImpact: { happy: 3, neutral: 1 } },
      { text: "Take a nature walk", moodImpact: { happy: 3, excited: 1 } },
      { text: "Meditate or do yoga", moodImpact: { happy: 4, neutral: 1 } },
      { text: "Watch comedy shows", moodImpact: { happy: 3, excited: 2 } }
    ]
  },
  {
    id: 23,
    text: "What's your favorite color and why?",
    category: 'stress-relief',
    options: [
      { text: "Blue - calm and peaceful", moodImpact: { happy: 3, neutral: 1 } },
      { text: "Yellow - bright and cheerful!", moodImpact: { excited: 2, happy: 3 } },
      { text: "Green - natural and refreshing", moodImpact: { happy: 3, neutral: 1 } },
      { text: "Purple - creative and magical!", moodImpact: { excited: 2, happy: 2 } }
    ]
  },
  {
    id: 24,
    text: "If you could tell your past self one thing, what would it be?",
    category: 'stress-relief',
    options: [
      { text: "Everything will be okay", moodImpact: { happy: 4, neutral: 1 } },
      { text: "You're stronger than you think", moodImpact: { happy: 3, excited: 2 } },
      { text: "Enjoy the journey!", moodImpact: { happy: 3, excited: 2 } },
      { text: "Believe in yourself more", moodImpact: { happy: 4, excited: 1 } }
    ]
  },
  {
    id: 25,
    text: "What's your favorite way to celebrate small wins?",
    category: 'stress-relief',
    options: [
      { text: "Dance party for one!", moodImpact: { excited: 3, happy: 3 } },
      { text: "Treat myself to something nice", moodImpact: { happy: 3, excited: 1 } },
      { text: "Share it with friends", moodImpact: { happy: 3, excited: 2 } },
      { text: "Happy victory nap!", moodImpact: { happy: 3, neutral: 1 } }
    ]
  },
  {
    id: 26,
    text: "What sound brings you instant calm?",
    category: 'stress-relief',
    options: [
      { text: "Ocean waves", moodImpact: { happy: 4, neutral: 2 } },
      { text: "Rain on the roof", moodImpact: { happy: 4, neutral: 1 } },
      { text: "Birds chirping", moodImpact: { happy: 3, excited: 1 } },
      { text: "Crackling fireplace", moodImpact: { happy: 3, neutral: 1 } }
    ]
  },
  {
    id: 27,
    text: "If you could hug anyone right now, who would it be?",
    category: 'stress-relief',
    options: [
      { text: "A loved one", moodImpact: { happy: 4, excited: 1 } },
      { text: "My pet", moodImpact: { happy: 4, excited: 1 } },
      { text: "My future successful self!", moodImpact: { excited: 3, happy: 3 } },
      { text: "A giant teddy bear", moodImpact: { happy: 3, excited: 2 } }
    ]
  },
  {
    id: 28,
    text: "What's your ultimate comfort food?",
    category: 'stress-relief',
    options: [
      { text: "Mac and cheese - ultimate comfort!", moodImpact: { happy: 3, excited: 1 } },
      { text: "Chocolate - instant mood boost!", moodImpact: { happy: 3, excited: 2 } },
      { text: "Pizza - always reliable!", moodImpact: { happy: 3, excited: 2 } },
      { text: "Ice cream - cold and comforting!", moodImpact: { happy: 4, excited: 1 } }
    ]
  },
  {
    id: 29,
    text: "When was the last time you laughed really hard?",
    category: 'stress-relief',
    options: [
      { text: "Today! Life is good!", moodImpact: { excited: 3, happy: 4 } },
      { text: "This week - had some fun moments", moodImpact: { happy: 3, excited: 1 } },
      { text: "Recently, can't remember exactly", moodImpact: { happy: 2, neutral: 1 } },
      { text: "It's been a while, need more laughs!", moodImpact: { happy: 2, excited: 2 } }
    ]
  },
  {
    id: 30,
    text: "Right now, in this moment, I feel...",
    category: 'stress-relief',
    options: [
      { text: "Better than when I started!", moodImpact: { happy: 4, excited: 3 } },
      { text: "Pretty good actually!", moodImpact: { happy: 3, excited: 2 } },
      { text: "Ready to take on the world!", moodImpact: { excited: 4, happy: 4 } },
      { text: "Grateful for this moment", moodImpact: { happy: 4, excited: 2 } }
    ]
  }
];
